<?php




function pix_elementor_templates_heading(){
    $templates = array();
    $thumb_path = PIX_CORE_PLUGIN_URI . 'functions/vc_templates/custom/thumbnails/headings/';

    $data = array (
        'id' => 'startup-heading',
        'file' => 'sections/heading/startup-heading.json',
        'title' => 'Startup heading',
        'thumbnail' => $thumb_path.'startup-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/startup/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'software-heading',
        'file' => 'sections/heading/software-heading.json',
        'title' => 'software heading',
        'thumbnail' => $thumb_path.'software-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/software/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'saas-heading',
        'file' => 'sections/heading/saas-heading.json',
        'title' => 'saas heading',
        'thumbnail' => $thumb_path.'saas-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/saas/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'saas-heading-dark',
        'file' => 'sections/heading/saas-heading-dark.json',
        'title' => 'saas heading dark',
        'thumbnail' => $thumb_path.'saas-heading-dark.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/saas/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'crypto-heading',
        'file' => 'sections/heading/crypto-heading.json',
        'title' => 'crypto-heading',
        'thumbnail' => $thumb_path.'crypto-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/cryptocurrency/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'services-heading',
        'file' => 'sections/heading/services-heading.json',
        'title' => 'services-heading',
        'thumbnail' => $thumb_path.'services-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/services/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );

    array_push($templates, $data);

    $data = array (
        'id' => 'medical-heading',
        'file' => 'sections/heading/medical-heading.json',
        'title' => 'medical-heading',
        'thumbnail' => $thumb_path.'medical-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/medical/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'marketing-heading',
        'file' => 'sections/heading/marketing-heading.json',
        'title' => 'marketing-heading',
        'thumbnail' => $thumb_path.'marketing-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/marketing/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'creative-heading',
        'file' => 'sections/heading/creative-heading.json',
        'title' => 'creative-heading',
        'thumbnail' => $thumb_path.'creative-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/creative/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'creative-heading-simple',
        'file' => 'sections/heading/creative-heading-simple.json',
        'title' => 'creative-heading-simple',
        'thumbnail' => $thumb_path.'creative-heading-simple.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/creative/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'ebook-heading',
        'file' => 'sections/heading/ebook-heading.json',
        'title' => 'ebook-heading',
        'thumbnail' => $thumb_path.'ebook-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/ebook/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'restaurant-heading',
        'file' => 'sections/heading/restaurant-heading.json',
        'title' => 'restaurant-heading',
        'thumbnail' => $thumb_path.'restaurant-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/restaurant/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'business-heading',
        'file' => 'sections/heading/business-heading.json',
        'title' => 'business-heading',
        'thumbnail' => $thumb_path.'business-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/business/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'product-heading-circles',
        'file' => 'sections/heading/product-heading-circles.json',
        'title' => 'product-heading-circles',
        'thumbnail' => $thumb_path.'product-heading-circles.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/product/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'coronavirus-heading-circles',
        'file' => 'sections/heading/coronavirus-heading-circles.json',
        'title' => 'coronavirus-heading-circles',
        'thumbnail' => $thumb_path.'coronavirus-heading-circles.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/coronavirus/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'influencer-heading',
        'file' => 'sections/heading/influencer-heading.json',
        'title' => 'influencer-heading',
        'thumbnail' => $thumb_path.'influencer-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/influencer/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'photography-heading',
        'file' => 'sections/heading/photography-heading.json',
        'title' => 'photography-heading',
        'thumbnail' => $thumb_path.'photography-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/photography/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'beauty-heading',
        'file' => 'sections/heading/beauty-heading.json',
        'title' => 'beauty-heading',
        'thumbnail' => $thumb_path.'beauty-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/beauty/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);

    $data = array (
        'id' => 'original-main-heading',
        'file' => 'sections/heading/original-main-heading.json',
        'title' => 'original-main-heading',
        'thumbnail' => $thumb_path.'original-main-heading.png',
        'tmpl_created' => '1520443695',
        'author' => 'pixfort',
        'url' => 'https://essentials.pixfort.com/original/',
        'type' => 'block',
        'subtype' => 'intro',
        'tags' => '["heading"]',
        'menu_order' => '0',
        'popularity_index' => '0',
        'trend_index' => '0',
        'has_page_settings' => '0',
    );
    array_push($templates, $data);


    return $templates;
}




 ?>
